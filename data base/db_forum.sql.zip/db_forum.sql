-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 29, 2015 at 09:24 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_forum`
--

-- --------------------------------------------------------

--
-- Table structure for table `acount`
--

CREATE TABLE IF NOT EXISTS `acount` (
  `id_acount` int(10) NOT NULL auto_increment,
  `nm_depan` varchar(25) collate latin1_general_ci NOT NULL,
  `nm_belakang` varchar(25) collate latin1_general_ci NOT NULL,
  `email` varchar(25) collate latin1_general_ci NOT NULL,
  `password` varchar(100) collate latin1_general_ci NOT NULL,
  `jk` varchar(15) collate latin1_general_ci NOT NULL,
  `tgl_lahir` date NOT NULL,
  `foto` varchar(45) collate latin1_general_ci NOT NULL,
  `aktif` enum('1','0') collate latin1_general_ci NOT NULL default '0',
  PRIMARY KEY  (`id_acount`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=30 ;

--
-- Dumping data for table `acount`
--

INSERT INTO `acount` (`id_acount`, `nm_depan`, `nm_belakang`, `email`, `password`, `jk`, `tgl_lahir`, `foto`, `aktif`) VALUES
(29, 'Nella', 'Novirina', 'Nellanovrina@gmail.com', '12345', 'Perempuan', '1994-11-09', 'B612-2015-09-20-11-44-15.jpg', '1'),
(28, 'surya', 'mukni', 'suryamukni@yahoo.com', '12345', 'Laki-Laki', '1994-01-10', 'imsages.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL auto_increment,
  `username` varchar(100) collate latin1_general_ci NOT NULL,
  `password` varchar(100) collate latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) collate latin1_general_ci NOT NULL,
  `email` varchar(100) collate latin1_general_ci NOT NULL,
  `no_telp` varchar(20) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `nama_lengkap`, `email`, `no_telp`) VALUES
(13, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin@gmail.com', '123123'),
(16, 'surya', 'aff8fbcbf1363cd7edc85a1e11391173', 'surya febrianto mukni', 'suryamukni@yahoo.com', '000000');

-- --------------------------------------------------------

--
-- Table structure for table `balas_status`
--

CREATE TABLE IF NOT EXISTS `balas_status` (
  `id_balas` int(10) NOT NULL auto_increment,
  `id_status` varchar(10) collate latin1_general_ci NOT NULL,
  `id_acount` varchar(10) collate latin1_general_ci NOT NULL,
  `balas` text collate latin1_general_ci NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY  (`id_balas`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=39 ;

--
-- Dumping data for table `balas_status`
--

INSERT INTO `balas_status` (`id_balas`, `id_status`, `id_acount`, `balas`, `waktu`) VALUES
(38, '37', '28', 'hahahha', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE IF NOT EXISTS `download` (
  `id_download` int(5) NOT NULL auto_increment,
  `judul` varchar(100) collate latin1_general_ci NOT NULL,
  `nama_file` varchar(100) collate latin1_general_ci NOT NULL,
  `format_file` varchar(20) collate latin1_general_ci NOT NULL,
  `tgl_posting` date NOT NULL,
  `hits` int(3) NOT NULL,
  PRIMARY KEY  (`id_download`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `download`
--

INSERT INTO `download` (`id_download`, `judul`, `nama_file`, `format_file`, `tgl_posting`, `hits`) VALUES
(1, 'modul fisika', 'BBM_4_(Usaha_dan_Energi)_KD_Fisika.pdf', 'PDF', '2014-12-03', 1),
(2, 'tugas sejarah', 'peta rute penyebaran nenek moyang.docx', 'DOC', '2014-12-03', 1),
(4, 'modul bahasa inggris', 'Preposition_Power_Mini.ppt', 'PPT', '2014-12-03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `kd_kategori` varchar(8) NOT NULL,
  `nm_kategori` varchar(25) NOT NULL,
  `ket` varchar(255) NOT NULL,
  PRIMARY KEY  (`kd_kategori`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kd_kategori`, `nm_kategori`, `ket`) VALUES
('KT-0001', 'MULTIMEDIA', 'FORUM MULTIMEDIA'),
('KT-0002', 'UPW', 'Disini Tempat '),
('KT-0003', 'AKUNTANSI', 'Disini Tempat Berdiskusi Tentang Ilmu Pengetahuan Umum'),
('KT-0004', 'PERKANTORAN', 'SEKTERIS');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `idkomen` int(11) NOT NULL auto_increment,
  `id_post` varchar(8) NOT NULL,
  `id_acount` varchar(45) NOT NULL,
  `isi` varchar(255) NOT NULL,
  `waktu_komen` datetime NOT NULL,
  PRIMARY KEY  (`idkomen`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `komentar`
--


-- --------------------------------------------------------

--
-- Table structure for table `pengunjung`
--

CREATE TABLE IF NOT EXISTS `pengunjung` (
  `id_pengunjung` int(10) NOT NULL auto_increment,
  `id_acount` varchar(10) collate latin1_general_ci NOT NULL,
  `waktu` time NOT NULL,
  `tgl` date NOT NULL,
  PRIMARY KEY  (`id_pengunjung`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=84 ;

--
-- Dumping data for table `pengunjung`
--

INSERT INTO `pengunjung` (`id_pengunjung`, `id_acount`, `waktu`, `tgl`) VALUES
(83, '28', '11:00:53', '2015-09-26'),
(82, '28', '22:04:21', '2015-09-25'),
(81, '28', '21:52:32', '2015-09-25'),
(80, '29', '21:49:41', '2015-09-25'),
(79, '28', '17:57:12', '2015-09-25'),
(78, '28', '12:49:59', '2015-09-22'),
(77, '28', '13:12:37', '2015-09-21'),
(76, '28', '11:03:41', '2015-09-20'),
(75, '28', '10:37:42', '2015-09-20'),
(74, '28', '10:21:29', '2015-09-20'),
(73, '28', '09:47:48', '2015-09-20'),
(72, '28', '15:41:17', '2015-09-19'),
(71, '28', '15:13:12', '2015-09-19'),
(70, '28', '11:41:51', '2015-09-18'),
(69, '28', '08:48:47', '2015-09-18');

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

CREATE TABLE IF NOT EXISTS `posting` (
  `id_post` int(8) NOT NULL auto_increment,
  `kd_subk` varchar(8) NOT NULL,
  `id_acount` varchar(45) NOT NULL,
  `judul` varchar(45) NOT NULL,
  `isi` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `waktu_post` datetime NOT NULL,
  PRIMARY KEY  (`id_post`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `posting`
--

INSERT INTO `posting` (`id_post`, `kd_subk`, `id_acount`, `judul`, `isi`, `file`, `waktu_post`) VALUES
(2, 'SK-0001', 'surya@yahoo.com', 'sharing off good', 'mencritakan ten tabhgadha', 'small_keyboard.rar', '2015-09-16 08:02:34'),
(3, 'SK-0004', 'suryamukni@yahoo.com', 'cara booking tiket', 'tata cara', '335-1020-1-PB_2.pdf', '2015-09-26 11:01:59');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id_status` int(10) NOT NULL auto_increment,
  `id_acount` varchar(10) collate latin1_general_ci NOT NULL,
  `status` text collate latin1_general_ci NOT NULL,
  `waktu` time NOT NULL,
  PRIMARY KEY  (`id_status`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=38 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `id_acount`, `status`, `waktu`) VALUES
(37, '29', 'Lelah ', '21:51:44');

-- --------------------------------------------------------

--
-- Table structure for table `sub_kategori`
--

CREATE TABLE IF NOT EXISTS `sub_kategori` (
  `kd_subk` varchar(8) NOT NULL,
  `nm_subk` varchar(25) NOT NULL,
  `kd_kategori` varchar(8) NOT NULL,
  `ket` varchar(255) NOT NULL,
  PRIMARY KEY  (`kd_subk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sub_kategori`
--

INSERT INTO `sub_kategori` (`kd_subk`, `nm_subk`, `kd_kategori`, `ket`) VALUES
('SK-0004', 'resevation', 'KT-0002', 'tatat cara resevation'),
('SK-0003', 'surat menyurat', 'KT-0004', 'tata cara surat'),
('SK-0001', 'asasasas', 'KT-0001', 'suryaaaaa'),
('SK-0002', 'asasasas', 'KT-0003', 'msmdsdks');

-- --------------------------------------------------------

--
-- Table structure for table `t_soal`
--

CREATE TABLE IF NOT EXISTS `t_soal` (
  `no` int(11) NOT NULL auto_increment,
  `soal` text NOT NULL,
  `a` varchar(1000) NOT NULL,
  `b` varchar(1000) NOT NULL,
  `c` varchar(1000) NOT NULL,
  `d` varchar(1000) NOT NULL,
  `kunci` varchar(1000) NOT NULL,
  PRIMARY KEY  (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `t_soal`
--

INSERT INTO `t_soal` (`no`, `soal`, `a`, `b`, `c`, `d`, `kunci`) VALUES
(1, 'Siapa presiden pertama Indonesia', 'Soekarno', 'Suharto', 'Ki Hajar Dewantara', 'Megawati Soekarno Puteri', 'Soekarno'),
(2, 'Apa kepanjangan dari NKRI', 'Negara Kesatuan Rakyat Indonesia', 'Negara Kesatuan Republik Indonesia', 'Negara Kedaulatan Republik Indonesia', 'Negara Kekeluargaan Rakyat Indonesia', 'Negara Kesatuan Republik Indonesia'),
(3, '2 + 2 = ', '10:3', '8:4', '(2:2)x(2*2)', '7:3', '(2:2)x(2*2)'),
(4, 'UPI merupakan singkatan dari', 'Universitas Padahal IKIP', 'Universitas Pendidikan Indonesia', 'Universitas Pelawak Internasional', 'Semua Benar', 'Universitas Pendidikan Indonesia'),
(5, 'Siapa nama ayah Arum Yuniarsih', 'Ruman', 'Jajang', 'Dedi', 'Sarbini', 'Ruman'),
(6, 'Malaikat pencabut nyawa adalah malaikat', 'Izroil', 'Jibril', 'Mikail', 'Isrofil', 'Izroil'),
(7, 'siapa nama malaikat peniup sangsakala...', 'isroil', 'isrofil', 'ridwan', 'nahi mungkar', 'isrofil'),
(8, '10+1000+20+2000+30+3000+40+4000=....', '10000', '10100', '11000', '10010', '10100'),
(9, 'didalam cabang bronkus di dLmny TERDAPAT CABANG LAGI YANG DISEBUT....', 'BRONKUS', 'BRONKIOLUS', 'BRONKTIS', 'ALVEOLUS', 'BRONKIOLUS'),
(10, 'Bagian tanaman yang berfungsi menyerap air dari da...', 'tudung akar', 'bulu akar', 'ujung batang', 'ujung akar', 'B'),
(11, 'sdsdsda', 'asa', 'sd', 'asd', 'a', 'a');
